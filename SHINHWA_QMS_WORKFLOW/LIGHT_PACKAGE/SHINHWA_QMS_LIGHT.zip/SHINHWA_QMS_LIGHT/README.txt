﻿SHINHWA QMS LIGHT — 로컬 드라이브 조사·정리·복사 도구 (읽기 전용 위주)

1) Python 3.10 이상 설치 (설치 화면에서 Add python.exe to PATH 체크)
2) 이 폴더에서 명령 프롬프트(cmd)를 열고:
     python -m pip install -r requirements.txt
     set PYTHONUTF8=1
3) 드라이브 조사(내용은 읽지 않고 이름만 집계, 아무것도 바꾸지 않음):
     python scripts\qms_workflow.py drivescan E:/
   결과: 12_OUTPUT\REPORTS\drivescan_*.md
4) 정리 미리보기 / 복사(원본은 그대로 두고 복사만):
     python scripts\qms_workflow.py foldertree E:/SHINHWA
     python scripts\qms_workflow.py organizeplan E:/정리할폴더 E:/SHINHWA
     python scripts\qms_workflow.py organizeplan E:/정리할폴더 E:/SHINHWA --apply
5) 경로는 E:/ 처럼 슬래시(/)로 쓰세요. "E:\" 처럼 끝에 역슬래시를 붙이면 오류가 납니다.
